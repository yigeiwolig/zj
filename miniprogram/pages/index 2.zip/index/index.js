// index/index.js
const app = getApp();

// 引入腾讯地图SDK
var QQMapWX = require('../../utils/qqmap-wx-jssdk.js'); 
var qqmapsdk = new QQMapWX({
    key: 'WYWBZ-ZFY3G-WLKQV-QOD5M-2S6EJ-CSF7Z' // 你的Key
});

Page({
  data: {
    isAuthorized: false, // 是否通过昵称验证
    inputNickName: '', 
    showSettingModal: false, // 定位授权引导弹窗
    step: 0, // 动画步骤
    mockLocation: null,
    
    // 定位分析结果
    locationAnalysis: {
      done: false,      // 是否分析完成
      isBlocked: false, // 是否被拦截
      data: null        // 详细数据(用于上传数据库)
    },
    
    isReady: false, 
    isBypass: false // 是否管理员特赦
  },

  onLoad(options) {
    // 1. 同步全局模拟定位
    if (app.globalData.mockLocation) {
      this.setData({ mockLocation: app.globalData.mockLocation });
    }

    // 2. 封禁检查 (最高优先级)
    const isBanned = wx.getStorageSync('is_user_banned');
    if (isBanned) {
      wx.reLaunch({ url: '/pages/blocked/blocked' });
      return;
    }

    // 3. 管理员放行检查 (Bypass)
    // 从 blocked 页面跳转回来时会带上 bypass=1
    const pages = getCurrentPages();
    const currentPage = pages[pages.length - 1] || {};
    const pageOptions = currentPage.options || options || {};
    
    if (pageOptions.bypass === '1') {
      console.log('✅ 管理员放行进入');
      this.setData({ isBypass: true, isAuthorized: true });
      // 特赦用户不需要复查昵称，直接准备就绪
      this.initResources();
      return;
    }

    // 4. 昵称缓存复查
    // 即使有缓存，也要去云端问一下“我现在还能用吗？”(处理单次放行逻辑)
    const hasAuth = wx.getStorageSync('has_authorized_user');
    const cachedNickname = wx.getStorageSync('user_nickname');

    if (hasAuth && cachedNickname) {
      console.log('🔍 正在复查本地缓存昵称...');
      wx.cloud.callFunction({
        name: 'verifyNickname',
        data: { nickname: cachedNickname }
      }).then(res => {
        const result = res.result || {};
        if (result.isBlocked) {
          console.log('⛔ 复查未通过，清除缓存');
          wx.removeStorageSync('has_authorized_user');
          this.setData({ isAuthorized: false });
          
          if (result.isBanned) {
             wx.setStorageSync('is_user_banned', true);
             wx.reLaunch({ url: '/pages/blocked/blocked' });
          }
        } else {
          console.log('✅ 复查通过');
          this.setData({ isAuthorized: true });
        }
      }).catch(err => {
        // 断网情况下，如果有缓存，暂时信任缓存
        console.error('复查网络错误', err);
        this.setData({ isAuthorized: true });
      }).finally(() => {
        this.initResources();
      });
    } else {
      this.setData({ isAuthorized: false });
      this.initResources();
    }
  },

  // 初始化资源 (蓝牙等) - 不做定位
  initResources() {
    const tasks = [
      this.initBluetoothPreCheck(),
      new Promise(resolve => setTimeout(resolve, 1000))
    ];
    Promise.all(tasks).then(() => {
      this.setData({ isReady: true });
    });
  },

  // ============================================================
  // 交互流程 1: 昵称验证
  // ============================================================

  onNickNameInput(e) { this.setData({ inputNickName: e.detail.value }); },
  onNickNameChange(e) { this.setData({ inputNickName: e.detail.value }); },

  handleDeny() {
    wx.showModal({ title: '提示', content: '需要获取权限才能继续', showCancel: false });
  },

  handleLogin() {
    const nickName = this.data.inputNickName.trim();
    if (!nickName) { wx.showToast({ title: '请输入昵称', icon: 'none' }); return; }

    wx.showLoading({ title: '验证中' });

    wx.cloud.callFunction({
      name: 'verifyNickname', 
      data: { nickname: nickName }
    }).then(res => {
      wx.hideLoading();
      const result = res.result || {};
      const attemptCount = result.currentCount || 0;

      // 1. 封禁处理
      if (result.isBanned) {
        wx.setStorageSync('is_user_banned', true);
        wx.reLaunch({ url: '/pages/blocked/blocked' });
        return;
      }

      // 2. 验证失败处理
      if (result.isBlocked) {
        // 超过5次，跳转
        if (attemptCount > 5) {
          wx.redirectTo({ url: `/pages/blocked/blocked?type=nickname&count=${attemptCount}` });
          return;
        }
        // 弹窗提示
        const isCritical = attemptCount >= 4;
        wx.showModal({
          title: '验证失败', 
          content: isCritical ? '请联系管理员\n微信号：MT-mogaishe' : `昵称错误\n(剩余次数: ${5 - attemptCount})`, 
          showCancel: false,
          confirmText: isCritical ? '一键复制' : '重试',
          success: (res) => {
            if (res.confirm && isCritical) {
              wx.setClipboardData({ data: 'MT-mogaishe' });
            }
          }
        });
      } else {
        // 3. 验证成功
        wx.setStorageSync('has_authorized_user', true);
        wx.setStorageSync('user_nickname', nickName);
        this.setData({ isAuthorized: true });
        wx.showToast({ title: '验证通过', icon: 'success' });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '网络异常', icon: 'none' });
    });
  },

  // ============================================================
  // 交互流程 2: 点击按钮 -> 强制定位 -> 动画 -> 跳转
  // ============================================================

  handleAccess() {
    // 动画中禁止点击
    if (this.data.step > 0) return;

    if (!this.data.isAuthorized) {
      wx.showToast({ title: '请先完成上方验证', icon: 'none' });
      return;
    }

    // 第一步：检查并强制请求定位授权
    this.checkLocationAuth();
  },

  // 检查权限
  checkLocationAuth() {
    wx.getSetting({
      success: (res) => {
        const auth = res.authSetting['scope.userLocation'];
        if (auth === true) {
          // 已授权 -> 开始核心流程
          this.setData({ showSettingModal: false });
          this.startMainProcess();
        } else if (auth === false) {
          // 拒绝过 -> 弹窗引导去设置
          this.setData({ showSettingModal: true });
        } else {
          // 首次 -> 弹窗请求
          this.requestLocationAuth();
        }
      }
    });
  },

  requestLocationAuth() {
    wx.authorize({
      scope: 'scope.userLocation',
      success: () => { this.startMainProcess(); },
      fail: () => { this.checkLocationAuth(); } // 拒绝后重新检查，触发引导弹窗
    });
  },

  openSetting(e) {
    this.setData({ showSettingModal: false });
    if (e.detail.authSetting['scope.userLocation']) {
      this.startMainProcess();
    } else {
      this.setData({ showSettingModal: true });
    }
  },

  // ============================================================
  // 核心流程：并行执行 [动画] 和 [定位分析]
  // ============================================================
  startMainProcess() {
    // 1. 如果是管理员特赦，不做定位检测，直接跑动画
    if (this.data.isBypass) {
        this.runAnimation();
        // 伪造一个通过的定位结果
        this.setData({ 
            locationAnalysis: { done: true, isBlocked: false } 
        });
        return;
    }

    // 2. 正常流程：重置状态
    this.setData({ 
        locationAnalysis: { done: false, isBlocked: false, data: null } 
    });

    // 3. 并行启动
    this.runAnimation();        // 启动视觉 (耗时约 2.5s)
    this.analyzeLocation();     // 启动逻辑 (耗时约 0.5s - 1s)
  },

  // 纯粹的定位分析逻辑
  analyzeLocation() {
    console.log('🚀 开始定位分析...');
    wx.getLocation({
      type: 'gcj02',
      isHighAccuracy: true,
      success: (res) => {
        const { latitude, longitude } = res;
        
        qqmapsdk.reverseGeocoder({
          location: { latitude, longitude },
          success: (mapRes) => {
            const result = mapRes.result;
            const comp = result.address_component;
            let province = comp.province || '';
            const rawAddress = result.address || '未知地址';

            // 模拟定位覆盖
            if (this.data.mockLocation === 'hangzhou') province = '浙江省';
            if (this.data.mockLocation === 'shenzhen') province = '广东省';

            // 判定逻辑：包含 "浙江" 且不在白名单 -> 拦截
            const isBlocked = province.indexOf('浙江') !== -1;

            // 准备数据包
            const logData = {
              nickName: wx.getStorageSync('user_nickname'),
              province,
              city: comp.city,
              address: rawAddress,
              latitude,
              longitude,
              isBlocked,
              createTime: new Date()
            };

            console.log('定位完成，结果:', isBlocked ? '拦截' : '放行');

            // 存入 user_list (记录所有访问)
            const db = wx.cloud.database();
            db.collection('user_list').add({ data: logData });

            // 更新状态，等待动画结束读取
            this.setData({
              locationAnalysis: {
                done: true,
                isBlocked: isBlocked,
                data: logData
              }
            });
          },
          fail: (err) => {
            console.error('逆地址解析失败', err);
            // 失败默认放行
            this.setData({ locationAnalysis: { done: true, isBlocked: false } });
          }
        });
      },
      fail: (err) => {
        console.error('获取坐标失败', err);
        // 失败默认放行
        this.setData({ locationAnalysis: { done: true, isBlocked: false } });
      }
    });
  },

  // 动画控制
  runAnimation() {
    this.setData({ step: 1 });
    
    setTimeout(() => { this.setData({ step: 2 }); }, 500);
    
    setTimeout(() => {
      this.setData({ step: 3 }); // 冲刺
      
      setTimeout(() => {
        this.setData({ step: 4 }); // 停留
        
        // 紧接着执行掉落和跳转判断
        this.doFallAndSwitch();

      }, 1900); 
    }, 1300);
  },

  // 动画最后一步：掉落并根据定位结果跳转
  doFallAndSwitch() {
    this.setData({ step: 5 }); // 掉落动画

    // 等待掉落动画(0.8s)完成
    setTimeout(() => {
      this.checkResultAndJump();
    }, 800); 
  },

  // 最终判决
  checkResultAndJump() {
    const analysis = this.data.locationAnalysis;

    // 如果动画跑完了，但定位还没回来 (极少数情况)
    if (!analysis.done) {
      console.log('⏳ 定位未完成，等待中...');
      wx.showLoading({ title: '安全检查中' });
      // 轮询等待
      setTimeout(() => {
        wx.hideLoading();
        this.checkResultAndJump();
      }, 500);
      return;
    }

    // 定位已出结果
    if (analysis.isBlocked) {
      console.log('⛔ 命中地域拦截，跳转 Blocked 页面');
      
      // 只有在确定要拦截时，才写入 blocked_users 数据库
      if (analysis.data) {
        wx.cloud.callFunction({
          name: 'sendBlockedUser',
          data: analysis.data
        });
      }

      // 跳转拦截页
      wx.reLaunch({
        url: '/pages/blocked/blocked',
        success: () => { this.setData({ step: 0 }); }
      });

    } else {
      console.log('✅ 通过检查，跳转 Products 页面');
      wx.reLaunch({
        url: '/pages/products/products',
        success: () => { this.setData({ step: 0 }); }
      });
    }
  },

  // 蓝牙相关
  initBluetoothPreCheck() {
    return new Promise((resolve) => {
      wx.openBluetoothAdapter({
        success: () => resolve(true),
        fail: () => resolve(false)
      });
    });
  },
  
  setMockLocation(e) {
    const city = e.currentTarget.dataset.city;
    this.setData({ mockLocation: city });
    app.globalData.mockLocation = city;
    wx.showToast({ title: '模拟定位已切换', icon: 'none' });
  }
});