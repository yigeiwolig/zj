Page({
  data: {
    currentIndex: 0,
    verticalMargin: 0,
    list: [
      { 
        id: 3, 
        title: '产品上新', 
        en: 'NEW ARRIVALS', 
        gradient: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)', 
        // 【已修复】完美镂空星标礼盒 - 解决了星星破碎的问题
        // 重新绘制了路径，确保星星是干净的剪切效果，星星位置已调整到礼盒正中间
        iconSvg: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI0ZGRkZGRiI+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNMjAsNkgxNlY0QTIsMiAwIDAsMCAxNCwySDEwQTIsMiAwIDAsMCA4LDRWNkg0QTIsMiAwIDAsMCAyLDhWMTFBMSwxIDAgMCwwIDMsMTJWMjBBMiwyIDAgMCwwIDUsMjJIMTlBMiwyIDAgMCwwIDIxLDIwVjEyQTEsMSAwIDAsMCAyMiwxMVY4QTIsMiAwIDAsMCAyMCw2Wk0xMiwxNi40TDguMjQsMTguNjdMOS4yNCwxNC4zOUw1LjkyLDExLjUxTDEwLjMsMTAuODdMMTIsNi44NkwxMy43MSwxMC44N0wxOC4wOCwxMS41MUwxNC43NiwxNC4zOUwxNS43NiwxOC42N0wxMiwxNi40WiIvPjwvc3ZnPg=="
      },
      { 
        id: 4, 
        title: '产品选购', 
        en: 'SHOPPING', 
        // 【已修改】极光紫：高端、神秘、品质
        gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 
        // 图标：购物车 (保持不变)
        iconSvg: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI0ZGRkZGRiI+PHBhdGggZD0iTTE3LDE4QTIsMiAwIDAsMSAxOSwyMEEyLDIgMCAwLDEgMTcsMjJDMTUuODksMjIgMTUsMjEuMSAxNSwyMEMxNSwxOC44OSAxNS44OSwxOCAxNywxOE0xLDJWNEgyTDYuNiwxMS41OUw1LjI0LDE0LjA0QzUuMDksMTQuMzIgNSwxNC42NSA1LDE1QTIsMiAwIDAsMCA3LDE3SDE5VjE1SDcuNDJBMC4yNSwwLjI1IDAgMCwxIDcuMTcsMTQuNzVDNy4xNywxNC43IDcuMTgsMTQuNjYgNy4yLDE0LjYzTDguMSwxM0gxNS41NUMxNi4zLDEzIDE2Ljk2LDEyLjU4IDE3LjMsMTEuOTdMMjAuODgsNS41QzIwLjk1LDUuMzQgMjEsNS4xNyAyMSw1QTEsMSAwIDAgMCAyMCw0SDUuMjFMNC4yNywyTTcsMThBMiwyIDAgMCAxIDksMjBBMiwyIDAgMCAxIDcsMjJDNS44OSwyMiA1LDIxLjEgNSwyMEM1LDE4Ljg5IDUuODksMTggNywxOFoiLz48L3N2Zz4="
      },
      { 
        id: 1, 
        title: '控制中心', 
        en: 'CONTROL CENTER', 
        gradient: 'linear-gradient(135deg, #2C3E50 0%, #000000 100%)', 
        iconSvg: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI0ZGRkZGRiI+PHBhdGggZD0iTTExLDJWNC4wN0M3LjM4LDQuNTMgNC41Myw3LjM4IDQuMDcsMTFIMlYxM0g0LjA3QzQuNTMsMTYuNjIgNy4zOCwxOS40NyAxMSwxOS45M1YyMkgxM1YxOS45M0MxNi42MiwxOS40NyAxOS40NywxNi42MiAxOS45MywxM0gyMlYxMUgxOS45M0MxOS40Nyw3LjM4IDE2LjYyLDQuNTMgMTMsNC4wN1YySDExTTEyLDZBNiw2IDAgMCwxIDE4LDEyQTYsNiAwIDAsMSAxMiwxOEE2LDYgMCAwLDEgNiwxMkE2LDYgMCAwLDEgMTIsNk0xMiw4QTQsNCAwIDAsMCA4LDEyQTQsNCAwIDAsMCAxMiwxNkE0LDQgMCAwLDAgMTYsMTJBNCw0IDAgMCwwIDEyLDhaIi8+PC9zdmc+"
      },
      { 
        id: 5, 
        title: '排行榜单', 
        en: 'RANKING LIST', 
        gradient: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)', 
        iconSvg: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI0ZGRkZGRiI+PHBhdGggZD0iTTQsMThWMTNIOVYxOEg0TTEwLDE4VjlIMTVWMThIMTBNMTYsMThWMTRIMjFWMThIMTZaIi8+PC9zdmc+"
      },
      { 
        id: 2, 
        title: '我的信息', 
        en: 'MY PROFILE', 
        gradient: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)', 
        iconSvg: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI0ZGRkZGRiI+PHBhdGggZD0iTTEyLDE5LjJDOS41LDE5LjIgNy4yOSwxNy45MiA2LDE2QzYuMDMsMTQgMTAsMTIuOSAxMiwxMi45QzE0LDEyLjkgMTcuOTcsMTQgMTgsMTZDMTYuNzEsMTcuOTIgMTQuNSwxOS4yIDEyLDE5LjJNMTIsNUEzLDMgMCAwLDEgMTUsOEEzLDMgMCAwLDEgMTIsMTFBMywzIDAgMCwxIDksOEEzLDMgMCAwLDEgMTIsNU0xMiwyQTEwLDEwIDAgMCwwIDIsMTJBMTAsMTAgMCAwLDAgMTIsMjJBMTAsMTAgMCAwLDAgMjIsMTJBMTAsMTAgMCAwLDAgMTIsMloiLz48L3N2Zz4="
      }
    ]
  },

  onLoad() {
    // 先设置一个默认值，让页面立即显示，避免白屏
    const sysInfo = wx.getSystemInfoSync();
    const cardSlotHeightRpx = 450;
    const cardSlotHeightPx = (sysInfo.windowWidth / 750) * cardSlotHeightRpx;
    const margin = (sysInfo.windowHeight - cardSlotHeightPx) / 2;
    
    // 立即设置，不等待异步
    this.setData({
      verticalMargin: margin
    });
  },

  calculateMargin() {
    const sysInfo = wx.getSystemInfoSync();
    
    // 【关键修改点】
    // 将卡片槽高度从 280 增加到 450。
    // 物理卡片高度依然是 CSS 里的 280rpx。
    // 这意味着每个卡片会有 (450-280)=170rpx 的隐形安全距离。
    const cardSlotHeightRpx = 450; 
    
    const cardSlotHeightPx = (sysInfo.windowWidth / 750) * cardSlotHeightRpx;
    const margin = (sysInfo.windowHeight - cardSlotHeightPx) / 2;

    this.setData({
      verticalMargin: margin
    });
  },

  onSwiperChange(e) {
    this.setData({
      currentIndex: e.detail.current
    });
  },

  goBack() {
    // 返回到首页
    wx.reLaunch({
      url: '/pages/index/index'
    });
  }
});
