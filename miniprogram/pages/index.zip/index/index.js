Page({
  data: {
    isAnimating: false,
    step: 0, 
    // 0:静止, 1:变身, 2:左滚, 3:右滚(文字出), 4:停在右边, 5:掉落并转场
  },

  handleAccess() {
    if (this.data.isAnimating) return;

    // --- 阶段1：变身 (0ms) ---
    // 水滴迅速收缩成齿轮
    this.setData({ isAnimating: true, step: 1 });

    // --- 阶段2：向左蓄力 (500ms后) ---
    setTimeout(() => {
      this.setData({ step: 2 });
    }, 500);

    // --- 阶段3：向右冲刺 (1300ms后) ---
    // 左滚用了800ms，稍微停顿一下再往右
    setTimeout(() => {
      this.setData({ step: 3 });
    }, 1300);

    // --- 阶段4：停在最右边并立即跳转 (3300ms后) ---
    // 右滚设定为2秒，滚到尽头后立即跳转
    setTimeout(() => {
      this.setData({ step: 4 });
      // 齿轮滚到右边后立即跳转到产品页
      wx.reLaunch({
        url: '/pages/products/products',
        success: () => {
          this.setData({ isAnimating: false, step: 0 });
        }
      });
    }, 3300);
  }
});
