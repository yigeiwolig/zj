// index/index.js
const app = getApp();

// 确保你的 SDK 路径是对的
var QQMapWX = require('../../utils/qqmap-wx-jssdk.js'); 

var qqmapsdk = new QQMapWX({
    key: 'WYWBZ-ZFY3G-WLKQV-QOD5M-2S6EJ-CSF7Z' 
});

// 默认头像
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0';

Page({
  data: {
    isAuthorized: false,
    showAuthModal: false, // 控制弹窗
    inputNickName: '', 
    avatarUrl: defaultAvatarUrl,
    
    // 动画相关
    step: 0,
    mockLocation: null, 
  },

  onLoad() {
    // 检查缓存，如果以前验证过，直接进
    const hasAuth = wx.getStorageSync('has_authorized_user');
    if (hasAuth) {
      this.setData({ isAuthorized: true });
    } else {
      // 没验证过，开始环境检测
      this.startEnvironmentCheck();
    }
  },

  // ==========================================
  // 1. 环境检测 (修复：必须等全部完成后才弹窗)
  // ==========================================
  startEnvironmentCheck() {
    wx.showLoading({ title: '环境初始化...', mask: true });

    // 使用 Promise 链式调用，确保顺序执行
    this.checkLocation()
      .then(() => {
        return this.checkBluetooth();
      })
      .then(() => {
        // 全部成功/结束，隐藏 Loading，显示弹窗
        wx.hideLoading();
        this.setData({ showAuthModal: true });
      })
      .catch((err) => {
        // 即使中间出错，最后也要把弹窗显示出来，不然用户进不去了
        console.error('环境检测异常:', err);
        wx.hideLoading();
        this.setData({ showAuthModal: true });
      });
  },

  // 封装定位检查
  checkLocation() {
    return new Promise((resolve) => {
      wx.getLocation({
        type: 'gcj02',
        success: (res) => {
          console.log('定位完成');
          resolve();
        },
        fail: (err) => {
          console.log('定位失败或拒绝');
          resolve(); // 失败也 resolve，让流程继续
        }
      });
    });
  },

  // 封装蓝牙检查
  checkBluetooth() {
    return new Promise((resolve) => {
      wx.openBluetoothAdapter({
        success: (res) => {
          console.log('蓝牙开启');
          resolve();
        },
        fail: (err) => {
          console.log('蓝牙未开启');
          resolve(); // 失败也 resolve
        }
      });
    });
  },

  // ==========================================
  // 2. 输入逻辑 (已删除所有拦截代码)
  // ==========================================
  
  // 只需要最简单的更新数据
  onNickNameInput(e) {
    this.setData({ inputNickName: e.detail.value });
  },
  
  // 兼容微信键盘的一键填入
  onNickNameChange(e) {
    this.setData({ inputNickName: e.detail.value });
  },

  onChooseAvatar(e) {
    this.setData({ avatarUrl: e.detail.avatarUrl });
  },

  // ==========================================
  // 3. 登录验证 (核心：呼叫云函数)
  // ==========================================
  handleLogin() {
    const { inputNickName, avatarUrl } = this.data;

    // 简单非空判断
    if (!inputNickName) {
      wx.showToast({ title: '请输入昵称', icon: 'none' });
      return;
    }
    // 如果你强制要求选头像，把下面注释打开
    /*
    if (avatarUrl === defaultAvatarUrl) {
      wx.showToast({ title: '请选择头像', icon: 'none' });
      return;
    }
    */

    wx.showLoading({ title: '验证身份...', mask: true });

    // 调用云函数
    wx.cloud.callFunction({
      name: 'checkAuth',
      data: {
        nickName: inputNickName.trim() // 去掉空格
      },
      success: (res) => {
        wx.hideLoading();
        const result = res.result;

        if (result.success) {
          // --- 成功 (或者是本人回来) ---
          wx.showToast({ title: result.msg, icon: 'success' });
          
          // 写入本地缓存
          wx.setStorageSync('has_authorized_user', true);
          wx.setStorageSync('userInfo', { 
            nickName: inputNickName, 
            avatarUrl: avatarUrl 
          });

          // 关闭弹窗，显示主页
          this.setData({ isAuthorized: true });

        } else {
          // --- 失败 (不在名单，或被抢注) ---
          wx.vibrateLong();
          wx.showModal({
            title: '验证失败',
            content: result.msg, // 会显示"不在名单"或"已被占用"
            showCancel: false,
            confirmText: '重试',
            confirmColor: '#FF3B30'
          });
        }
      },
      fail: (err) => {
        wx.hideLoading();
        wx.showToast({ title: '网络错误', icon: 'none' });
        console.error(err);
      }
    });
  },

  handleDeny() {
    // 拒绝授权，这里可以退出小程序或者提示
    wx.showToast({ title: '需验证通过才可使用', icon: 'none' });
  },

  // 设置模拟定位
  setMockLocation(e) {
    // 防抖：如果正在处理，直接返回
    if (this._isSettingLocation) {
      console.log('正在设置定位，忽略重复点击');
      return;
    }
    
    const city = e.currentTarget.dataset.city;
    console.log('设置模拟定位:', city);
    
    // 标记正在处理
    this._isSettingLocation = true;
    
    // 同时更新本地和全局数据
    this.setData({ mockLocation: city });
    app.globalData.mockLocation = city;
    
    wx.showToast({
      title: city === 'hangzhou' ? '已切换到杭州' : '已切换到深圳',
      icon: 'none',
      duration: 1500
    });

    // 延迟一下后重新检查定位（通过 app.js 的检查函数）
    setTimeout(() => {
      // 检查 app.js 是否有 checkAccess 方法
      if (app.checkAccess) {
        app.checkAccess();
      } else {
        console.warn('app.js 中未定义 checkAccess 方法');
      }
      
      // 1秒后重置标记，允许下次点击
      setTimeout(() => {
        this._isSettingLocation = false;
      }, 1000);
    }, 500);
  },

  // 点击液态按钮/齿轮
  handleAccess() {
    // 1. 如果动画正在进行，不处理
    if (this.data.step > 0) return;

    // 2. 显示加载中，防止用户连点
    wx.showLoading({ title: '安全检测中...', mask: true });

    // 3. 获取经纬度
    wx.getLocation({
      type: 'gcj02', // 使用国测局坐标系，在国内地图上更准
      isHighAccuracy: true, // 【关键】开启高精度模式 (GPS + WiFi + 基站)
      highAccuracyExpireTime: 4000, // 高精度定位超时时间(ms)
      success: (res) => {
        const lat = res.latitude;
        const lng = res.longitude;

        qqmapsdk.reverseGeocoder({
          location: { latitude: lat, longitude: lng },
          get_poi: 1,
          success: (mapRes) => {
            const result = mapRes.result;
            
            // 1. 获取推荐建筑名
            const address = result.address; 
            const building = result.formatted_addresses ? result.formatted_addresses.recommend : address;

            // 2. 提取省市区结构化数据
            const comp = result.address_component;
            const province = comp.province; // 省
            const city = comp.city;         // 市
            const district = comp.district; // 区

            console.log('解析地址成功:', province, city, district, building);

            // 3. 传给云函数
            wx.cloud.callFunction({
              name: 'accessControl',
              data: {
                latitude: lat,
                longitude: lng,
                addressDetail: address,
                buildingName: building,
                province: province,
                city: city,
                district: district,
                nickName: wx.getStorageSync('userInfo')?.nickName || '',
                deviceInfo: 'User Device'
              },
              success: (cloudRes) => {
                wx.hideLoading();
                const result = cloudRes.result;
                if (result.isBlocked) {
                  wx.showModal({ title: '访问受限', content: result.msg, showCancel: false });
                  return;
                }
                this.runAnimation();
              },
              fail: (err) => {
                wx.hideLoading();
                // 即使云函数失败，为了体验也放行动画（或根据需求拦截）
                this.runAnimation(); 
              }
            });
          },
          fail: (error) => {
            console.error('地图解析失败', error);
            // 解析失败时的兜底调用（只传坐标）
            wx.cloud.callFunction({
               name: 'accessControl',
               data: { latitude: lat, longitude: lng }
            });
          }
        });
      },
      fail: () => {
        wx.hideLoading();
        wx.showToast({ title: '需要位置权限', icon: 'none' });
      }
    });
  },

  // 动画逻辑
  runAnimation() {
    // === Step 1: 变身 (水滴 -> 齿轮) ===
    this.setData({ step: 1 });
    
    // 0.5s 后进入 Step 2
    setTimeout(() => {
      // === Step 2: 蓄力 (向左滚) ===
      this.setData({ step: 2 });
      
      // 0.8s 后进入 Step 3
      setTimeout(() => {
        // === Step 3: 冲刺 (向右滚 + 文字跳出) ===
        this.setData({ step: 3 });

        // 1.6s (滚动结束) + 0.3s (短暂停留) = 1.9s 后进入下一步
        setTimeout(() => {
          // === Step 4: 停留展示完成，准备掉落 ===
          this.setData({ step: 4 }); 
          
          // 紧接着执行掉落
          this.doFallAndSwitch();

        }, 1900); // 1600ms滚动 + 300ms短暂停留

      }, 800); 

    }, 500);
  },

  doFallAndSwitch() {
    // === Step 5: 齿轮掉落 ===
    this.setData({ step: 5 });

    // 等待掉落动画完成（0.8s）后再跳转
    setTimeout(() => {
      wx.reLaunch({
        url: '/pages/products/products', // 跳转到扫描页
        success: () => {
          this.setData({ step: 0 });
        }
      });
    }, 800); // 等待掉落动画完成
  }
});
