// cloudfunctions/verifyNickname/index.js
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { nickname } = event || {}
  const wxContext = cloud.getWXContext()
  const OPENID = wxContext.OPENID
  
  // 先处理 blocked_users 逻辑，支持管理员临时放行
  try {
    const blockedResult = await db.collection('blocked_users').where({ openid: OPENID }).get()

    if (blockedResult.data.length > 0) {
      const userData = blockedResult.data[0];

      // 检测管理员是否开启了“临时放行”开关
      if (userData.temporaryRelease === true) {
        // 1. 消耗掉这次放行机会 (关掉开关)
        // 2. 重置尝试次数 (attemptCount)
        await db.collection('blocked_users').doc(userData._id).update({
          data: {
            temporaryRelease: false,
            attemptCount: 0,
            updateTime: db.serverDate()
          }
        });

        // 直接返回放行成功，不再执行后面的拦截逻辑
        return {
          isBlocked: false,
          msg: '管理员已放行，重置次数'
        };
      }

      // 默认仍然被拦截
      return { success: false, isBlocked: true }
    }
  } catch (e) {
    console.error('blocked_users check failed', e)
    // 不中断流程，继续后续逻辑
  }

  try {
    // ====================================================
    // 1. 获取日志记录
    // ====================================================
    let logRecord = null
    const logRes = await db.collection('login_logs').where({ _openid: OPENID }).get()

    if (logRes.data.length > 0) {
      logRecord = logRes.data[0]
    } else {
      // 默认创建一条记录，包含临时放行开关字段
      logRecord = { _openid: OPENID, attemptCount: 0, status: 'pending', temporaryRelease: false }
    }

    // 检测 login_logs 中的临时放行开关（管理员放行）
    if (logRecord && logRecord.temporaryRelease === true) {
      const recordId = logRecord._id
      await db.collection('login_logs').doc(recordId).update({
        data: {
          temporaryRelease: false,
          attemptCount: 0,
          releaseTime: db.serverDate() // 记录放行时间
        }
      })

      return {
        isBlocked: false,
        msg: '管理员已临时放行昵称验证，尝试次数已归零'
      }
    }

    // 如果没有昵称且未命中放行逻辑，则提示缺少昵称
    if (!nickname) return { success: false, msg: '昵称不能为空' }

    const recordId = logRecord._id

    // ============= 昵称比对逻辑（黑名单/白名单 + 抢座） =============
    const { isViolating, reason } = await checkNicknameForViolations(db, nickname);
    const currentCount = logRecord.attemptCount || 0;

    if (isViolating) {
      const newCount = currentCount + 1;
      let newStatus = newCount >= 5 ? 'banned' : 'pending';
      let isBanned = newCount >= 5;

      const failData = {
        nickname,
        lastTryTime: db.serverDate(),
        attemptCount: newCount,
        status: newStatus
      };

      if (recordId) {
        await db.collection('login_logs').doc(recordId).update({ data: failData });
      } else {
        await db.collection('login_logs').add({ data: { _openid: OPENID, temporaryRelease: false, ...failData, createTime: db.serverDate() } });
      }

      return { 
        success: false, 
        isBlocked: true, 
        currentCount: newCount, 
        isBanned, 
        msg: reason 
      };
    }

    // 昵称合规但曾有失败记录，清除记录放行
    if (recordId && (logRecord.attemptCount || 0) > 0) {
      await db.collection('login_logs').doc(recordId).remove();
      return { success: true, isBlocked: false, msg: '昵称合规，记录已清除' };
    }

    // 注意：这里删除了“一旦被封禁立刻返回”的逻辑，是为了让下面的开关有机会生效

    // ====================================================
    // 2. 验证逻辑 (优先级：VIP > 全局开关 > 个人单次开关)
    // ====================================================
    let isPassed = false
    let passReason = ''

    // A. 抢座逻辑 (查 valid_users)
    // ... (省略具体的抢座查询，保持之前的逻辑，或者简化为查白名单) ...
    // 为了防止逻辑太复杂，这里先简单查白名单，如果你需要抢座逻辑请保留之前的代码
    // 这里假设基本的白名单检查：
    const validRes = await db.collection('valid_users').where({ nickname: nickname }).get()
    const seats = validRes.data
    // 简单的抢座/白名单判定
    for (let seat of seats) {
      if (seat._openid === OPENID) { isPassed = true; passReason = 'vip_return'; break; }
      if (!seat._openid) { 
        // 占座
        await db.collection('valid_users').doc(seat._id).update({ data: { _openid: OPENID, claimTime: new Date() }});
        isPassed = true; passReason = 'vip_new'; break; 
      }
    }

    // B. 全局开关 (invite_gate) - 能解封
    if (!isPassed) {
       try {
         const gateRes = await db.collection('system_config').doc('invite_gate').get()
         if (gateRes.data.isOpen === true) {
           await db.collection('system_config').doc('invite_gate').update({ data: { isOpen: false } })
           isPassed = true; passReason = 'gate'
         }
       } catch (e) {}
    }

    // C. 个人单次开关 (allowOneTime) - 能解封
    // 【这就是你要的功能】
    if (!isPassed && logRecord.allowOneTime === true) {
      isPassed = true; passReason = 'one_time'
    }

    // ====================================================
    // 3. 结果处理
    // ====================================================
    
    if (isPassed) {
      // === 验证通过 (同时执行解封) ===
      const successData = {
        nickname: nickname,
        lastTryTime: new Date(),
        status: 'used',      // 状态变回正常
        attemptCount: 0,     // 🌟 次数清零！
        allowOneTime: false  // 关闭开关
      }
      
      if (logRecord._id) {
        await db.collection('login_logs').doc(logRecord._id).update({ data: successData })
      } else {
        await db.collection('login_logs').add({ data: { _openid: OPENID, temporaryRelease: false, ...successData } })
      }
      return { success: true }

    } else {
      // === 验证失败 ===
      
      // 在这里才检查是否被封禁
      // 如果之前已经是 banned，或者这次错误导致 banned
      const newCount = (logRecord.attemptCount || 0) + 1
      let newStatus = logRecord.status || 'pending'
      
      if (logRecord.status === 'banned') {
        // 如果本来就是 banned，且没通过上面的开关，那就继续 banned
        return { success: false, isBanned: true, msg: '已封禁' }
      }

      let isBanned = false
      if (newCount >= 5) {
        newStatus = 'banned'
        isBanned = true
      }

      const failData = {
        nickname: nickname,
        lastTryTime: new Date(),
        attemptCount: newCount,
        status: newStatus
      }

      if (logRecord._id) {
        await db.collection('login_logs').doc(logRecord._id).update({ data: failData })
      } else {
        await db.collection('login_logs').add({ data: { _openid: OPENID, temporaryRelease: false, ...failData, createTime: new Date() } })
      }

      return { 
        success: false, 
        currentCount: newCount, 
        isBanned: isBanned,
        msg: '验证失败'
      }
    }

  } catch (err) {
    console.error(err)
    return { success: false, error: err }
  }
}

/**
 * 检查昵称是否违规 (是否在 valid_users 白名单中)。
 * @param {object} db - 数据库实例
 * @param {string} nickname - 用户输入的昵称
 * @returns {Promise<{isViolating: boolean, reason: string}>}
 */
async function checkNicknameForViolations(db, nickname) {
  if (!nickname || nickname.trim().length === 0) {
    return { isViolating: true, reason: '昵称不能为空' };
  }

  // 1. 查 valid_users (昵称白名单)
  const validRes = await db.collection('valid_users').where({ nickname: nickname }).count();
  
  if (validRes.total > 0) {
    // 昵称在白名单中，合规通过
    return { isViolating: false, reason: '昵称在白名单中' };
  }

  // 2. 昵称不在白名单中，视为违规
  return { isViolating: true, reason: '该昵称未通过验证' };
}